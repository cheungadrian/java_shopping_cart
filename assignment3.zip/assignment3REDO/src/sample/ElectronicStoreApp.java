package sample;
import javafx.application.Application;                                                                                  //imports
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.event.*;
import javafx.scene.input.*;

public class ElectronicStoreApp extends Application{                                                                    //main application / controller
    private ElectronicStore model;                                                                                      //sets up models and views
    private ElectronicStoreView view;

    public void start(Stage primaryStage){                                                                              //start up
        model = ElectronicStore.createStore();
        view = new ElectronicStoreView(model);
        model.copystock();

        view.getReset_button().setOnAction(new EventHandler<ActionEvent>() {                                            //handles events (for this one handles what happens if the reset button was clicked)
            public void handle(ActionEvent actionEvent) {
                handleReset();
            }
        });

        view.getRemove_button().setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                handleRemove();
            }
        });

        view.getAdd_to_cart_button().setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                handleAdd_to_cart();
            }
        });

        view.getComplete_button().setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                handleComplete();
                handleUpdateDollarspersale();
            }
        });

        view.getInventory_list().setOnMouseReleased(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent mouseEvent) {
                view.update();
            }
        });

        view.getCurrentCart_list().setOnMouseReleased(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent mouseEvent) {
                view.update();
            }
        });

        primaryStage.setTitle("Electronic Store Application - "+ model.getName());                                      // Set title of window
        primaryStage.setScene(new Scene(view, 800,400));                                                  // Set size of window
        primaryStage.setResizable(false);                                                                               //make it not resizable
        primaryStage.show();                                                                                            //show

    }
    private void handleUpdateDollarspersale() {                                                                         //how to handle update dollar per sale scenario
        view.updatedollarspersale();
    }

    public void handleReset(){                                                                                          //handles the reset of the store
        model = ElectronicStore.createStore();                                                                          //creates a new store
        view.reset_store(model);                                                                                        //calls view.reset store
        model.copystock();                                                                                              //makes a new copy of original stock
        view.update();                                                                                                  //update view
        view.updatedollarspersale();                                                                                    //update dollar per sale field
    }

    public void handleRemove(){
        int index = view.getCurrentCart_list().getSelectionModel().getSelectedIndex();
        if(index >= 0){
            model.remove_item(index);
        }
        view.update();
    }

    public void handleAdd_to_cart(){
        int index = view.getInventory_list().getSelectionModel().getSelectedIndex();
        if(index >= 0){
            model.addToCart(index);
        }
        view.update();
    }

    public void handleComplete(){
        model.Complete_sale();
        model.getMostPopular();
        view.update();
    }
}
