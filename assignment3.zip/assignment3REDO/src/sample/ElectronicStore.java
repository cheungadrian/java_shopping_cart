package sample;                                                                                                         //comes from folder sample
//Class representing an electronic store
//Has an array of products that represent the items the store can sell

import java.util.*;                                                                                                     //importing libraries
public class ElectronicStore{
    public final int MAX_PRODUCTS = 10;                                                                                 //Maximum number of products the store can have
    private int curProducts;
    private String name;                                                                                                //name of store
    private Product[] stock;                                                                                            //Array to hold all products
    private double revenue;
    private int numofsales;
    private double dollarpersale;
    private ArrayList CurrentCart;                                                                                      //current cart
    private Product[] MostPopularItems;                                                                                 //array of popular items
    private int numofitemsincart;
    private double CurrentCartValue;                                                                                    //how much the current cart is worth (items prices)
    private ArrayList SoldItems;
    private Product LastItem;                                                                                           //a variable to store the last selected product from the store (used for add to cart edge cases)
    private int[] originalstock;                                                                                        //the original stock, unmanipulated, used for comparasion

    public ElectronicStore(String initName){                                                                            //constructor
        revenue = 0.0;                                                                                                  //setting default values
        name = initName;
        stock = new Product[MAX_PRODUCTS];
        curProducts = 0;
        numofitemsincart = 0;
        CurrentCart = new ArrayList<Product>();
        originalstock = new int[MAX_PRODUCTS];
    }

    public void copystock(){
       for(int i = 0; i < getOccupiedlength(stock); i++){
           originalstock[i] = stock[i].getStockQuantity();
       }
    }


    public String getName(){                                                                                            //getter method for name
        return name;
    }

    public double getDollarpersale() {                                                                                  //getter for dollar per sale
        return dollarpersale;
    }

    public int getNumofsales() {                                                                                        //getter for number of sales
        return numofsales;
    }

    public void addToCart(int index){                                                                                   //add to cart method
        LastItem = getCurrentStock().get(index);                                                                        //remembers the last item
        if(getCurrentStock().get(index).getStockQuantity() > 1) {                                                       //if stock quantity over 1
            numofitemsincart++;                                                                                         //increase number of items in the cart
            CurrentCartValue = CurrentCartValue + getCurrentStock().get(index).getPrice();                              //updates the shopping cart value
            getCurrentStock().get(index).setStock(getCurrentStock().get(index).getStockQuantity() - 1);                 //subtract the stock
            CurrentCart.add(getCurrentStock().get(index));                                                              //add to current cart
        }
        else if(getCurrentStock().get(index).getStockQuantity() == 1){                                                  //if the stock is specifically 1
            numofitemsincart++;                                                                                         //increase num of items in cart
            CurrentCartValue = CurrentCartValue + LastItem.getPrice();                                                  //uses the last item variable to update the cart value
            getCurrentStock().get(index).setStock(getCurrentStock().get(index).getStockQuantity() - 1);                 //subtract the stock
            CurrentCart.add(LastItem);

        }
    }

    public void Complete_sale() {                                                                                       //complete sales method
        numofsales++;                                                                                                   //increase number of sales by 1
        numofitemsincart = 0;                                                                                           //resetting values
        revenue = revenue + CurrentCartValue;                                                                           //calculates total money earned
        getCurrentCart().clear();                                                                                       //resetting
        dollarpersale = revenue / numofsales;                                                                           //calculates the dollar per sale
        CurrentCartValue = 0;                                                                                           //reset
        for (int i = 0; i < getOccupiedlength(stock); i++) {                                                            //add these items to the list of potentially popular items
           if(stock[i].getStockQuantity() != originalstock[i]){          //if statement to see if parameters are correct
               stock[i].setSoldQuantity(originalstock[i] - stock[i].getStockQuantity());             //subtract original stock by current stock to find out how many was sold
           }
        }
    }

    public void remove_item(int index){
        for(Product a : getCurrentStock()){
            if(a == getCurrentCart().get(index)){                                                                       //if the product matches the index
                getCurrentStock().get(index).setStock(getCurrentStock().get(index).getStockQuantity() + 1);             //increase stock quantity by 1
                numofitemsincart--;                                                                                     //reduce num of items in cart
                CurrentCartValue = CurrentCartValue - getCurrentStock().get(index).getPrice();                          //get current price
                CurrentCart.remove(getCurrentCart().get(index));                                                        //remove from cart
                break;
            }
            else{                                                                                                       //if item was not found in stock (ie it was sold out)
                getCurrentCart().get(index).setStock(1);                                                                //set stock of the item to 1
                numofitemsincart--;                                                                                     //reduce num of items in cart
                CurrentCartValue = CurrentCartValue - getCurrentCart().get(index).getPrice();                           //get the price
                getCurrentStock().add(getCurrentCart().get(index));                                                     //add to the current stock
                CurrentCart.remove(getCurrentCart().get(index));                                                        //remove from current cat
                break;
            }
        }
    }

    //Adds a product and returns true if there is space in the array
    //Returns false otherwise
    public boolean addProduct(Product newProduct){
        if(curProducts < MAX_PRODUCTS){
            stock[curProducts] = newProduct;
            curProducts++;
            return true;
        }
        return false;
    }

    public double getRevenue(){
        return revenue;
    }

    public double getCurrentCartValue(){
        return CurrentCartValue;
    }

    public ArrayList<Product> getCurrentStock() {
        if(curProducts <= 0){                                                                                           //if the store is sold out (no items)
            ArrayList<Product> Product_array_list = new ArrayList<Product>();                                           //returns an empty list
            return Product_array_list;
        }
        else{
            ArrayList<Product> Product_array_list = new ArrayList<Product>();
            for (int i = 0; i < curProducts; i++) {                                                                     //runs through the stock array. if it sees an item with 0 stock it wont add to current stock
                if (stock[i].getStockQuantity() > 0) {
                    Product_array_list.add(stock[i]);
                }
            }
            return Product_array_list;
        }
    }


    public void SortPopularItems(Product[] a) {                                                                         //Sorting used to find out which item is the most popular
        boolean flag = false;                                                                                         //flag used to detected if it is fully sorted
        Product temp;                                                                                                   //temporary holder variable used for the switch
        while(!flag) {                                                                                                //while loop
            flag = true;
            for(int i = 0; i < getOccupiedlength(a) - 1; i++) {
                if(a != null && a[i].getSoldQuantity() < a[i + 1].getSoldQuantity()){                                   //if the sold quantity less than the sold quantity a spot later than it
                    temp = a[i];                                                                                        //
                    a[i] = a[i + 1];
                    a[i + 1] = temp;
                    flag = false;
                }
            }
        }
    }

    public Product[] getMostPopular(){
        MostPopularItems = stock;
        SortPopularItems(MostPopularItems);
        Product[] temp = new Product[3];
        for(int i = 0; i< 3; i++){
            temp[i] = MostPopularItems[i];
        }
        return temp;
    }

    public ArrayList<Product> getCurrentCart(){
        return CurrentCart;
    }


    //Prints the stock of the store
    public void printStock(){
        for(int i = 0; i < curProducts; i++){
            if(stock[i].getStockQuantity() > 0){
                System.out.println(i + ". " + stock[i] + " (" + stock[i].getPrice() + " dollars each, " + stock[i].getStockQuantity() + " in stock, " + stock[i].getSoldQuantity() + " sold)");
            }
        }
    }

    public int getOccupiedlength(Object[] a){                                                                           //method in order to get the amount of occupied space in an array
        int occupiedspace = 0;                                                                                          //initialize variable occupied space (currently 0)
        for (int i = 0; i < a.length; i++){                                                                             //running through every element in product array
            if (a[i] != null){                                                                                          //if an occupied space is detected
                occupiedspace++;                                                                                        //counter will increase by one
            }
        }
        return occupiedspace;                                                                                           //returns the actual number of items inside that array
    }

    public static ElectronicStore createStore(){
        ElectronicStore store1 = new ElectronicStore("Watts Up Electronics");
        Desktop d1 = new Desktop(100, 10, 3.0, 16, false, 250, "Compact");
        Desktop d2 = new Desktop(200, 10, 4.0, 32, true, 500, "Server");
        Laptop l1 = new Laptop(150, 10, 2.5, 16, true, 250, 15);
        Laptop l2 = new Laptop(250, 10, 3.5, 24, true, 500, 16);
        Fridge f1 = new Fridge(500, 10, 250, "White", "Sub Zero", 15.5, false);
        Fridge f2 = new Fridge(750, 10, 125, "Stainless Steel", "Sub Zero", 23, true);
        ToasterOven t1 = new ToasterOven(25, 10, 50, "Black", "Danby", 8, false);
        ToasterOven t2 = new ToasterOven(75, 10, 50, "Silver", "Toasty", 12, true);
        store1.addProduct(d1);
        store1.addProduct(d2);
        store1.addProduct(l1);
        store1.addProduct(l2);
        store1.addProduct(f1);
        store1.addProduct(f2);
        store1.addProduct(t1);
        store1.addProduct(t2);
        return store1;
    }
}