package sample;
import javafx.scene.control.Label;                                                                                      //importing libraries
import javafx.scene.layout.Pane;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ElectronicStoreView extends Pane {                                                                         //making the view
    private ListView<Product> CurrentCart_list;                                                                         //declaring labels, fields etc
    private ListView<Product> Mostpopular_list;
    private ListView<Product> Inventory_list;
    ElectronicStore model;                                                                                              //use the MVC paradigm
    private Button Add_to_cart_button;
    private Button Remove_button;
    private Button Complete_button;
    private Button Reset_button;
    private Label CurrentCart_label;
    private Label Mostpop_label;
    private Label StoreStock_label;
    private Label StoreSum_label;
    private Label Num_sales_label;
    private Label Revenue_label;
    private Label Dollar_per_sale_label;
    private TextField salesfield;
    private TextField revenuefied;
    private TextField dollarpersalefield;
    //add more as we go

    public ListView getInventory_list(){ return Inventory_list; }                                                       //getters

    public Button getAdd_to_cart_button() {
        return Add_to_cart_button;
    }

    public ListView getCurrentCart_list(){
        return CurrentCart_list;
    }

    public Button getRemove_button() {
        return Remove_button;
    }

    public Button getComplete_button() {
        return Complete_button;
    }

    public Button getReset_button() {
        return Reset_button;
    }

    public ElectronicStoreView(ElectronicStore model) {
        this.model = model;                                                                                             //constructor


        //CREATING AND SETTING BUTTONS
        Reset_button = new Button("Reset store");
        Add_to_cart_button = new Button("Add to cart");
        Remove_button = new Button("Remove");
        Complete_button = new Button("Complete Sale");
        //MAKING THEM A PREFERRED SIZE
        Reset_button.setPrefSize(100, 25);
        Add_to_cart_button.setPrefSize(100, 25);
        Remove_button.setPrefSize(100, 25);
        Complete_button.setPrefSize(100, 25);

        //MAKING SURE BUTTONS ARE EVENLY SPACED
        Button[] buttons_arrays = new Button[4];
        buttons_arrays[0] = Reset_button;
        buttons_arrays[1] = Add_to_cart_button;
        buttons_arrays[2] = Remove_button;
        buttons_arrays[3] = Complete_button;
        //SETTING MOST BUTTONS TO DISABLED ON START UP
        for (int i = 0; i < 4; i++) {
            buttons_arrays[i].relocate(10 + i * 200, 370);
            buttons_arrays[i].setDisable(true);
        }
        buttons_arrays[0].setDisable(false);

        //MOST POPULAR LABELS
        Mostpop_label = new Label("Most popular:");
        Mostpop_label.relocate(10, 170);
        Mostpop_label.setPrefSize(100, 30);
        Mostpopular_list = new ListView<Product>();
        Mostpopular_list.relocate(5, 200);
        Mostpopular_list.setPrefSize(150, 150);

        //CURRENT CART LABELS
        CurrentCart_label = new Label("Current cart: $"+ model.getCurrentCartValue());
        CurrentCart_label.relocate(620, 25);
        CurrentCart_label.setPrefSize(150, 30);
        CurrentCart_list = new ListView<Product>();
        CurrentCart_list.relocate(490, 50);
        CurrentCart_list.setPrefSize(300, 300);


        //STORE STOCK LABELS
        StoreStock_label = new Label("Store Stock:");
        StoreStock_label.relocate(300, 25);
        StoreStock_label.setPrefSize(100, 30);
        Inventory_list = new ListView<Product>();
        Inventory_list.relocate(175, 50);
        Inventory_list.setPrefSize(300, 300);

        //STORE SUMMARY LABELS AND TEXTFIELDS
        StoreSum_label = new Label("Store Summary:");
        StoreSum_label.setPrefSize(100, 30);
        StoreSum_label.relocate(5, 0);
        Num_sales_label = new Label("# Sales:");
        Num_sales_label.setPrefSize(80, 30);
        Num_sales_label.relocate(5, 30);
        Revenue_label = new Label("Revenue:");
        Revenue_label.setPrefSize(80, 30);
        Revenue_label.relocate(5, 60);
        Dollar_per_sale_label = new Label("$/Sale:");
        Dollar_per_sale_label.setPrefSize(80, 30);
        Dollar_per_sale_label.relocate(5, 90);

        salesfield = new TextField();
        salesfield.relocate(50, 30);
        salesfield.setPrefSize(60, 30);
        revenuefied = new TextField();
        revenuefied.relocate(50, 60);
        revenuefied.setPrefSize(60, 30);
        dollarpersalefield = new TextField("NA");
        dollarpersalefield.relocate(50, 90);
        dollarpersalefield.setPrefSize(60, 30);

        salesfield.setEditable(false);
        revenuefied.setEditable(false);
        dollarpersalefield.setEditable(false);

        //ADDING TO THE SCENE
        getChildren().addAll(Remove_button, Add_to_cart_button, Reset_button, Complete_button, Mostpop_label, CurrentCart_label, StoreStock_label, StoreSum_label, Num_sales_label, Revenue_label, Dollar_per_sale_label, salesfield, revenuefied, dollarpersalefield, Mostpopular_list, Inventory_list, CurrentCart_list);

        //SETTING DEFAULT VALUES UPON INITIALIZATION
        String Number_of_sales_string = Integer.toString(model.getNumofsales());
        salesfield.setText(Number_of_sales_string);

        String Revenue_string = Double.toString(model.getRevenue());
        revenuefied.setText(Revenue_string);

        String Current_cart_string = Double.toString(model.getCurrentCartValue());
        CurrentCart_label.setText("Current cart: $"+ model.getCurrentCartValue());

        ObservableList<Product> Inventory_list_new = FXCollections.observableArrayList(model.getCurrentStock());
        Inventory_list.setItems(Inventory_list_new);

        ObservableList<Product> CurrentCart_list_new = FXCollections.observableArrayList(model.getCurrentCart());
        CurrentCart_list.setItems(CurrentCart_list_new);

        ObservableList<Product> Mostpopular_list_new = (ObservableList<Product>) FXCollections.observableArrayList(model.getMostPopular());
        Mostpopular_list.setItems(Mostpopular_list_new);
    }

    public void reset_store(ElectronicStore new_model){                                                                 //used to reset the store by setting the model to a new model
        this.model = new_model;
    }

    public void update() {                                                                                              //update method, updates all information to up to date
        String Number_of_sales_string = Integer.toString(model.getNumofsales());
        salesfield.setText(Number_of_sales_string);

        String Revenue_string = Double.toString(model.getRevenue());
        revenuefied.setText(Revenue_string);

        CurrentCart_label.setText("Current cart: $"+ model.getCurrentCartValue());

        ObservableList<Product> Inventory_list_new = FXCollections.observableArrayList(model.getCurrentStock());
        Inventory_list.setItems(Inventory_list_new);

        ObservableList<Product> CurrentCart_list_new = FXCollections.observableArrayList(model.getCurrentCart());
        CurrentCart_list.setItems(CurrentCart_list_new);

        ObservableList<Product> Mostpopular_list_new = FXCollections.observableArrayList(model.getMostPopular());
        Mostpopular_list.setItems(Mostpopular_list_new);

        int addtocartselection = Inventory_list.getSelectionModel().getSelectedIndex();                                 //parameters to determine if the button should be clickable or not
                if(addtocartselection == -1){
                    getAdd_to_cart_button().setDisable(true);
                }
                else{
                    getAdd_to_cart_button().setDisable(false);
                }

        int removecartselection = CurrentCart_list.getSelectionModel().getSelectedIndex();
                if(removecartselection == -1){
                    getRemove_button().setDisable(true);
                }

                else{
                    getRemove_button().setDisable(false);
                    getAdd_to_cart_button().setDisable(true);
                }

        if(CurrentCart_list_new.size() >0){                                                                             //parameters to determine if button should be clickable or not
            getComplete_button().setDisable(false);
            getAdd_to_cart_button().setDisable(false);
        }
        else{
            getComplete_button().setDisable(true);
        }
    }

    public void updatedollarspersale() {                                                                                //updating the dollar field, it is an edge case where the start up has to have a value of NA but every other instance can be anything else
        if(model.getDollarpersale() == 0){
            dollarpersalefield.setText("NA");
        }
        else{
            String Dollar_per_sale_string = Double.toString(model.getDollarpersale());
            dollarpersalefield.setText(Dollar_per_sale_string);
        }
    }
}
